<template>
    <view>

    </view>
</template>
<script lang="ts" setup>
import {paper}  from "./paper-full"
console.log(paper)
</script>
